#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private AQDFCINTBORB[] cacheAQDFCINTBORB;

		
		public AQDFCINTBORB AQDFCINTBORB(DateTime startTime, DateTime endTime)
		{
			return AQDFCINTBORB(Input, startTime, endTime);
		}


		
		public AQDFCINTBORB AQDFCINTBORB(ISeries<double> input, DateTime startTime, DateTime endTime)
		{
			if (cacheAQDFCINTBORB != null)
				for (int idx = 0; idx < cacheAQDFCINTBORB.Length; idx++)
					if (cacheAQDFCINTBORB[idx].StartTime == startTime && cacheAQDFCINTBORB[idx].EndTime == endTime && cacheAQDFCINTBORB[idx].EqualsInput(input))
						return cacheAQDFCINTBORB[idx];
			return CacheIndicator<AQDFCINTBORB>(new AQDFCINTBORB(){ StartTime = startTime, EndTime = endTime }, input, ref cacheAQDFCINTBORB);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.AQDFCINTBORB AQDFCINTBORB(DateTime startTime, DateTime endTime)
		{
			return indicator.AQDFCINTBORB(Input, startTime, endTime);
		}


		
		public Indicators.AQDFCINTBORB AQDFCINTBORB(ISeries<double> input , DateTime startTime, DateTime endTime)
		{
			return indicator.AQDFCINTBORB(input, startTime, endTime);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.AQDFCINTBORB AQDFCINTBORB(DateTime startTime, DateTime endTime)
		{
			return indicator.AQDFCINTBORB(Input, startTime, endTime);
		}


		
		public Indicators.AQDFCINTBORB AQDFCINTBORB(ISeries<double> input , DateTime startTime, DateTime endTime)
		{
			return indicator.AQDFCINTBORB(input, startTime, endTime);
		}

	}
}

#endregion
